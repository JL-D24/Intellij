package sda.traitement

import org.apache.spark.sql.{SparkSession, Row}
import org.apache.spark.sql.types.{StringType, StructType}
import org.scalatest.BeforeAndAfterAll
import org.scalatest.funsuite.AnyFunSuite
import sda.traitement.ServiceVente._

class ServiceVenteTest extends AnyFunSuite with BeforeAndAfterAll {
  private var spark: SparkSession = _

  override def beforeAll(): Unit = {
    spark = SparkSession.builder()
      .appName("SDA Unit Tests")
      .master("local")
      .getOrCreate()
  }

  override def afterAll(): Unit = {
    if (spark != null) spark.stop()
  }

  test("formatter doit créer et remplir les colonnes HTT et TVA") {

    val testData = Seq(Row("100,5|0,19"))
    val schema = new StructType().add("HTT_TVA", StringType, false)
    val df = spark.createDataFrame(spark.sparkContext.parallelize(testData), schema)
    val result = df.formatter().first()

    // Vérifications
    assert(result.schema.fields.length == 3)
    assert(result.getString(1) == "100,5")  // HTT
    assert(result.getString(2) == "0,19")   // TVA
  }

  test("calculTTC doit calculer correctement le montant TTC") {

    val testData = Seq(Row("100,5", "0,19"))
    val schema = new StructType()
      .add("HTT", StringType, false)
      .add("TVA", StringType, false)
    val df = spark.createDataFrame(spark.sparkContext.parallelize(testData), schema)
    val result = df.calculTTC().first()

    // Vérifications
    assert(result.schema.fields.length == 1)
    assert(result.getDouble(0) == 119.6)  // TTC
  }


  test("extractDateEndContratVille doit extraire correctement les données du JSON") {

    val jsonData = """{
      "MetaTransaction":[{
        "Ville":"Paris",
        "Date_End_contrat":"2020-12-23 00:00:00"
      }]}"""
    val testData = Seq(Row(jsonData))
    val schema = new StructType().add("MetaData", StringType, false)
    val df = spark.createDataFrame(spark.sparkContext.parallelize(testData), schema)
    val result = df.extractDateEndContratVille().first()

    // Vérifications
    assert(result.getString(0) == "Paris")         // Ville
    assert(result.getString(1) == "2020-12-23")    // Date_End_contrat
  }

  test("contratStatus doit identifier correctement les contrats actifs et expirés") {

    val testData = Seq(
      Row("3000-12-23"),  // Contrat futur (actif)
      Row("2020-12-23")   // Contrat passé (expiré)
    )
    val schema = new StructType().add("Date_End_contrat", StringType, false)
    val df = spark.createDataFrame(spark.sparkContext.parallelize(testData), schema)
    val results = df.contratStatus().collect()

    // Vérifications
    assert(results(0).getString(1) == "Actif")   // Contrat futur
    assert(results(1).getString(1) == "Expired")  // Contrat passé
  }
}