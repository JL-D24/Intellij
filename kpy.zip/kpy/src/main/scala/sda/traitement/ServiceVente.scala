package sda.traitement
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.types._


object ServiceVente {

  implicit class DataFrameUtils(dataFrame: DataFrame) {

    def formatter()= {
      dataFrame.withColumn("HTT", split(col("HTT_TVA"), "\\|")(0))
        .withColumn("TVA", split(col("HTT_TVA"), "\\|")(1))
    }

    def calculTTC () : DataFrame ={
      dataFrame
        .withColumn("HTT", regexp_replace(col("HTT"), ",", ".").cast(DoubleType))
        .withColumn("TVA", regexp_replace(col("TVA"), ",", ".").cast(DoubleType))
        .withColumn("TTC", round(col("HTT") + col("HTT") * col("TVA"), 2))
        .drop("HTT", "TVA")
    }

    def extractDateEndContratVille(): DataFrame = {
      val schema_MetaTransaction = new StructType()
        .add("Ville", StringType, false)
        .add("Date_End_contrat", StringType, false)
      val schema = new StructType()
        .add("MetaTransaction", ArrayType(schema_MetaTransaction), true)
      dataFrame
        .withColumn("ParsedMetaData", from_json(col("MetaData"), schema))
        .withColumn("Ville", col("ParsedMetaData.MetaTransaction.Ville")(0))
        .withColumn("Date_End_contrat", col("ParsedMetaData.MetaTransaction.Date_End_contrat")(0))
        .withColumn("Date_End_contrat", regexp_extract(col("Date_End_contrat"), "^(\\d{4}-\\d{2}-\\d{2})", 1))
        .drop("MetaData", "ParsedMetaData")
    }

    def contratStatus(): DataFrame = {
      dataFrame.withColumn("Contrat_Status",
        when(to_date(col("Date_End_contrat"), "yyyy-MM-dd") < current_date(), "Expired")
          .otherwise("Actif")
      )
    }


  }

}