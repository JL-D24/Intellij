package sda.reader

import org.apache.spark.sql.{DataFrame, SparkSession}

case class XmlReader(path: String, rowTag: Option[String] = None)
  extends Reader {
  val format = "com.databricks.spark.xml"

  def read()(implicit  spark: SparkSession): DataFrame = {
    spark.read
      .format(format)
      .option("rowTag", rowTag.getOrElse("Record"))
      .load(path)
  }
}

